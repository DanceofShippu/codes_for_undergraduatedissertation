//  Batch process images from slide scanner.
//  Within the root folder, look for folder names that contain ".Collection".
//  In each collection folder, process all folder names that contain "Layer".
//  In each layer folder, open and process the two files "CH0_Z.tif" and  
//  "CH1_Z.tif" using the macro "QIQmacro_SlideScanner5.ijm"
//  Use XML metadata to find the XY coords of the scanned image, insert
//  the XY coords into each filename, and sort files based on those coords
//  by appending a zero padded prefix to each filename.

import ij.*;
import ij.process.*;
import ij.gui.*;
import java.awt.*;
import ij.plugin.*;
import ij.plugin.frame.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import java.io.*;
import org.xml.sax.SAXException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathExpressionException;

import javax.swing.filechooser.*;

import java.util.Arrays;
import java.util.ArrayList;


public class SlideScanner_macro_batch_gauss_QIQ_v2 implements PlugIn {
	private String divider = "----------";
	private String defaultText = "NOTE:  Above thresholds are for jpeg visualizaiton only, NOT for quantification.";
	public void run(String arg) {
		//IJ.run("Close All");
		
		GenericDialog gd = new GenericDialog("New Image");
		gd.addChoice("Projection:",
                      new String[] {"Average Intensity","Max Intensity","Min Intensity","Sum Slices","Standard Deviation","Median"},
                      "Average Intensity");
		gd.addNumericField("Ch 1 Threshold Min: ", 0, 0);
		gd.addNumericField("Ch 1 Threshold Max: ", 65536, 0);
		gd.addNumericField("Ch 2 Threshold Min: ", 0, 0);
		gd.addNumericField("Ch 2 Threshold Max: ", 65536, 0);
		gd.addMessage(divider+"\n"+defaultText+"\n"+divider);
		gd.addChoice("Ch 1 Background Method: ", new String[] {"Rolling Ball","Gaussian Blur"}, "Rolling Ball");
		gd.addNumericField("Ch 1 Radius: ", 50, 0);
		gd.addChoice("Ch 2 Background Method: ", new String[] {"Rolling Ball","Gaussian Blur"}, "Gaussian Blur");
		gd.addNumericField("Ch 2 Radius: ", 10, 0);
		gd.addChoice("Ch 1 Color:",
                      new String[] {"Red","Green","Blue","Cyan","Magenta","Yellow"},
                      "Blue");
		gd.addChoice("Ch 2 Color:",
                      new String[] {"Red","Green","Blue","Cyan","Magenta","Yellow"},
                      "Green");
		gd.addChoice("Rotate CC:",
                      new String[] {"-none-","90","180","270"},
                      "90");
		gd.showDialog();
		if (gd.wasCanceled()) return;
		String projection = gd.getNextChoice();
		int ch1threshmin = (int)gd.getNextNumber();
		int ch1threshmax = (int)gd.getNextNumber();
		int ch2threshmin = (int)gd.getNextNumber();
		int ch2threshmax = (int)gd.getNextNumber();
		String ch1_bg_method = gd.getNextChoice();
		int ch1_bg_radius = (int)gd.getNextNumber();
		String ch2_bg_method = gd.getNextChoice();
		int ch2_bg_radius = (int)gd.getNextNumber();
		String ch1_color = gd.getNextChoice();
		String ch2_color = gd.getNextChoice();
		String rotate_cc = gd.getNextChoice();
		
		
		//IJ.run("Z Project...", "projection=["+projection+"]");

		File dir = new File(IJ.getDirectory("Choose a Directory "));
		
		String processedPath = makeProcessedFolder(dir);
		
		File[] fileList = dir.listFiles();
		for(File collectionDir : fileList){
			if(collectionDir.getName().contains(".Collection")){
				File[] fileList2 = collectionDir.listFiles();
				for(File layerDir : fileList2){
					if(layerDir.getName().contains("Layer")){
						String path = layerDir.getPath() + File.separator;
						Document xmlDocument = getXmlDoc(path  + "Layer-source-metadata.xml");
						String[] xyVal = doXpath(xmlDocument);
						String xVal = xyVal[0];
						String yVal = xyVal[0];
						// remove "-" and " mm" or other measurement
						xVal = xVal.replace("-","");
						xVal = xVal.replace(" .*","");
						yVal = yVal.replace("-","");
						yVal = yVal.replace(" .*","");
						// make sure there are 2 decimal places (assumes a decimal exists)
						x_decimal = xVal.split(".")[1];
						for(int i=0; i+x_decimal.length() < 2; i++){
							xVal = xVal + "0";
						}
						y_decimal = yVal.split(".")[1];
						for(int i=0; i+y_decimal.length() < 2; i++){
							yVal = yVal + "0";
						}
						// make sure x and y val is padded with zeros for alpha sorting
						while(xVal.length() < 10){
							xVal = "0" + xVal;
						}
						while(yVal.length() < 10){
							yVal = "0" + yVal;
						}
						IJ.log("valX: "+xVal);
						IJ.log("valY: "+yVal);

						IJ.open(path + "CH0_Z.tif");
						IJ.open(path + "CH1_Z.tif");
						String macroArgs = projection+","+ ch1threshmin +","+ ch1threshmax+","+ ch2threshmin +","+ ch2threshmax +","+ ch1_bg_method +","+ ch1_bg_radius +","+ ch2_bg_method +","+ ch2_bg_radius +","+ ch1_color +","+ ch2_color +","+ rotate_cc;
						IJ.runMacroFile("QIQmacro_SlideScanner5.ijm",macroArgs);
						ImagePlus imp = WindowManager.getCurrentImage();
						IJ.saveAsTiff(imp,processedPath + collectionDir.getName() + "_X"+xVal + "Y"+yVal + "_" + layerDir.getName() + ".tif");
						IJ.saveAs(imp,"jpg",processedPath + collectionDir.getName() +"_X"+xVal + "Y"+yVal + "_"+ layerDir.getName()+ ".jpg");
						IJ.run("Close All");
						//break;
					}
				}
				//break;
			}
		}
		
		// Rename all files in Processed folder (in order)
		// File dir = new File(IJ.getDirectory("Choose a Directory "));
		// File[] fileList = dir.listFiles();
		File processedDir = new File(processedPath);
		fileList = processedDir.listFiles();
		Arrays.sort(fileList);
		// get unique base filenames
		ArrayList<String> uniqueNames = new ArrayList<String>();
		for(File file : fileList){
			String fileName = file.getName();
			int pos = fileName.lastIndexOf(".");
			if (pos > 0 && pos < (fileName.length() - 1)) { // If '.' is not the first or last character.
				fileName = fileName.substring(0, pos);
			}
			if(!uniqueNames.contains(fileName)){
				uniqueNames.add(fileName);
			}
			IJ.log(fileName);
		}
		//for(String name : uniqueNames){
			//IJ.log(name);
		//}
		for(int i=0; i<uniqueNames.size(); i++){
			String u_name = uniqueNames.get(i);
			String pre = Integer.toString(i) + "_";
			while(pre.length() < 5){
				pre = "0" + pre;
			}
			for(File file : fileList){
				String f_name = file.getName();
				if(f_name.contains(u_name)){
					String path = file.getAbsolutePath();
					String new_name = pre+f_name;  // add padded zero prefix
					new_name.replace(" ","_"); // replace spaces with underscores
					path = path.replace(f_name, new_name);
					file.renameTo(new File(path));
					IJ.log(path);
				}
			}
		}
		IJ.log("Done");
	}
	
	String makeProcessedFolder(File mainDir){
		//get last directory and make processed folder
		String dir = mainDir.getPath();
		String processedPath = dir + File.separator + "Processed" + File.separator;
		//IJ.log(processedPath);
		
		try{
			File processedFile = new File(processedPath);
			if(!processedFile.exists() || !processedFile.isDirectory()){
				processedFile.mkdir();
			}
	
		}catch(Exception err){
			
		}
		return processedPath;

	}
	
	Document getXmlDoc(String filePath){
		DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = null;
		Document document = null;
		try {
			builder = builderFactory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();  
		}
		
		
		try {
			document = builder.parse(new FileInputStream(filePath));
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return document
;
	}
	
	String[] doXpath(Document xmlDoc){
		XPath xPath =  XPathFactory.newInstance().newXPath();
		String selectorX = "//ImageAxis0Origin/@value";
		String selectorY = "//ImageAxis1Origin/@value";
		String xVal = null;
		String yVal = null;
		try {
			//read a string value
			xVal = xPath.compile(selectorX).evaluate(xmlDoc);
			yVal = xPath.compile(selectorY).evaluate(xmlDoc);
			//Node node = (Node) xPath.compile(expression).evaluate(xmlDocument, XPathConstants.NODE);
		} catch(XPathExpressionException e) {
            e.printStackTrace();
        }      
       	String[] xyVal = {xVal,yVal};
		return xyVal;
	}
	

}

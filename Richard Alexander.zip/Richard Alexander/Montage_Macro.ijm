//Example plate name: NDExp_WellA01_Point0000_Seq0000.nd2


// plate index arrays
// 96 well -- A-H rows -- 12 col 
row = newArray("A","B","C","D","E","F","G","H");
col1 = newArray("01","02","03","04","05","06");
col2 = newArray("07","08","09","10","11","12");
numpoints = 4; //num points must be less than 5 or not all points will be found if duplicated (5*2=10 --> Point00010 <> Point0010)
inner_folder_match = "plate 55";//"Plate 26";//"completed/";//"Plate";//
process_folder_match = "";//"completed/";//"";//"completed/";

plateDir = getDirectory("Choose Directory");
plateFolders = getFileList(plateDir);
Array.sort(plateFolders);
setBatchMode(true);
for(ptf=0; ptf<plateFolders.length; ptf++){
	folder = plateFolders[ptf];
	print(plateDir+folder);
	print(endsWith(plateDir+folder,"/"));
	print(indexOf(folder, inner_folder_match));
	if(endsWith(plateDir+folder,"/") && indexOf(folder, inner_folder_match)>=0){
		print("running");
		doPlate(plateDir, folder, process_folder_match);
	}
}
setBatchMode(false);

function doPlate(plateDir, plateFolder, process_folder_match){
	dir = plateDir + plateFolder + process_folder_match;
	files = getFileList(dir);
	Array.sort(files);
	print("-------------------------------------------------");
	//Array.print(files);
	
	//Run each half of the plate
	col_montage_names = newArray(row.length * 2); //two halves of the plate
	col_montage_counter = 0;
	doHalfPlate(dir, col1, col_montage_names, 0);
	print("NAMES");
	Array.print(col_montage_names);
	doHalfPlate(dir, col2, col_montage_names, row.length);
	print("NAMES");
	Array.print(col_montage_names);
	
	//run("Images to Stack", "name=Stack title=[] use");

	doFinalConcat(col_montage_names);
	
	// create new image name
	if(indexOf(plateFolder,"/")>=0){
		imgname = substring(plateFolder, 0, indexOf(plateFolder,"/"));
	}else{
		imgname = plateFolder;
	}
	print("NAME: "+ imgname);
	saveAs("tiff", plateDir+plateFolder+imgname);
	run("Close All");
}




function doHalfPlate(dir, col, col_montage_names, col_montage_counter){
	for(i=0; i<row.length; i++){  //row.length
		//create dictionary arrays
		//row_img_name = newArray(numpoints);
		name_array = newArray(numpoints*row.length);
		point_array = newArray(numpoints*row.length);
		Array.fill(point_array, -1);
		this_row = 0;
		col_count = 0;
		for(pp=0; pp<numpoints; pp++){
			image_names = newArray(col.length);
			for(j=0; j<col.length; j++){	//column
				num = 0;
				//image_names = newArray(col.length);
				//currentFiles = newArray(8);
			//for(pp=0; pp<numpoints; pp++){ //find all duplicate points
				//expect only one duplicate point
				point_match_array = newArray(2);
				//search for name
				point_counter = 0;
				this_point = "Well"+row[i]+col[j]+"_Point000"+pp;
				//Matching points:
				for(k=0; k<files.length; k++){
					if(indexOf(files[k],this_point) >= 0){
						point_match_array[point_counter] = files[k];
						point_counter++;
					}
				}
				// decide which point is the right one to use
				if(point_counter == 1){ //only one point found
					name_array[this_row] = point_match_array[0];
					image_names[j] = point_match_array[0];
				}else{	//two points found
					date0 = File.lastModified(dir+point_match_array[0]);
					date1 = File.lastModified(dir+point_match_array[1]);
					if(date0 > date1){ 		//take the newest file
						name_array[this_row] = point_match_array[0];
						image_names[j] = point_match_array[0];
						//col_count++;
					}else{
						name_array[this_row] = point_match_array[1];
						image_names[j] = point_match_array[1];
						//col_count++;
					}					
				}
				if(image_names[j] != 0){
					//run the image if an image was found
					doSingleImage(dir+image_names[j]);
					print(name_array[this_row]);
				}
				
			}
			if(image_names[0] !=0){ //only do montage if images were found
				doRowMontage("Point000"+pp, image_names);//doRowMontage("Point000"+pt,image_names);<<<---------------------------------------------------------
				rename("Well"+row[i]+pp);
				fixContrast();
			}
		}
		print("COLUMN: Well"+row[i]);
		//print(""+indexOf(getTitle(),"WellA"));
		if(nImages>0){
			if(indexOf(getTitle(),"Well"+row[i])>=0){	//only do montage if image was created
				doColMontage("Well"+row[i]);
				rename(row[i]+col[0]);
				Array.print(col_montage_names);
				print(col_montage_counter);
				col_montage_names[col_montage_counter] = row[i]+col[0];
				col_montage_counter++;
				fixContrast();
			}
		}
		
	}
}



function doSingleImage(imagePath){
	//open(imageName);
	run("Bio-Formats Importer", "open=["+imagePath+"] autoscale color_mode=Default view=Hyperstack stack_order=XYCZT");
	title = getTitle();
	Stack.setPosition(2, 1, 1); //channel 2 (red nucleus), slice 1, frame 1
	print("---- "+title);
	run("Plot Z-axis Profile");
	Plot.getValues(xpoints, ypoints);
	rank=Array.rankPositions(ypoints);
	max_z=rank[rank.length-1]+1; //max z slice (1 indexed)
	//handle cases where the max is in the first or last frame
	if(max_z==1 || max_z==ypoints.length){
		max_z = 6;
	}
	start = max_z-1;
	stop =  max_z+1;
	close(); //closes plot window
	selectWindow(title);
	run("Z Project...", "start="+start+" stop="+stop+" projection=[Max Intensity]");
	rename("zproj");
	selectWindow(title);
	close();
	selectWindow("zproj");
	spltname = title;
	if(indexOf(title,"/")>=0){
		splt = split(title,"/");
		spltname= splt[splt.length-1];	//filename is last element of array after split
	}
	rename(spltname);
	//print("done");
}

function fixContrast(){
	Stack.setPosition(1, 1, 1);
	run("Enhance Contrast", "saturated=0.35");
	Stack.setPosition(2, 1, 1);
	run("Enhance Contrast", "saturated=0.35");
}

function doRowMontage(nameContains, image_names){
	// once all images are open for one montage...
	//run("Images to Stack", "name=Stack title=["+nameContains+"] use");
	print("Row Montage -- ARRAY");
	Array.print(image_names);
	//Array.sort(image_names);	//original file sort takes care of this
	all_names = "";
	for(nm=0; nm<=image_names.length; nm++){
		idx = nm+1;
		if(nm==image_names.length){
			all_names +=" image"+idx+"=[-- None --]";
		}else if(image_names[nm] != 0){
			all_names += " image"+idx+"="+image_names[nm];
		}	
	}
	print(all_names);
	run("Concatenate...", "  title=[Concatenated Stacks]"+all_names);
	rename("concat");
	setForegroundColor(0, 0, 0);
	run("Make Montage...", "columns="+col1.length+" rows=1 scale=1 border=20 use");
	close("concat");
}

function doColMontage(nameContains){
	// once all montages are created...
	//run("Images to Stack", "name=Stack title=["+nameContains+"] use");
	print("Column montage -- ARRAY");
	all_names = "";
	for(nm=0; nm<=numpoints; nm++){
		idx = nm+1;
		if(nm==numpoints){
			all_names +=" image"+idx+"=[-- None --]";
		}else{
			all_names += " image"+idx+"="+nameContains+nm;
		}	
	}
	print(all_names);
	run("Concatenate...", "  title=[Concatenated Stacks]"+all_names); //concatenate stacks in order to make montage
	rename("concat");
	setForegroundColor(0, 0, 0);
	run("Make Montage...", "columns=1 rows="+numpoints+" scale=1 border=10 use"); //make montage from stack
	close("concat");
}

function doFinalConcat(col_montage_names){
	//col_montage_names = newArray("A01", "C01", "D01", "E01", "F01", "G01", "H01", 0, "C07", "D07", "E07", "F07", "G07", 0, 0, 0);
	print("Final Concatenation -- ARRAY");
	Array.print(col_montage_names);
	all_names = "";
	nm_index = 1;
	for(cc=0; cc<=col_montage_names.length; cc++){
		//idx = cc+1;
		if(cc==col_montage_names.length){
			all_names +=" image"+nm_index+"=[-- None --]";
			nm_index++;
		}else if(col_montage_names[cc]!=0 && col_montage_names[cc]!="0"){
			all_names += " image"+nm_index+"="+col_montage_names[cc];
			nm_index++;
		}
	}
	print(all_names);
	run("Concatenate...", "  title=[Concatenated Montage]"+all_names);

	//add labels to each frame
	for(cc=0; cc<col_montage_names.length; cc++){
		if(col_montage_names[cc]!=0 && col_montage_names[cc]!="0"){
			Stack.setPosition(1, 1, cc+1);
			setMetadata("Label", col_montage_names[cc]);
			Stack.setPosition(2, 1, cc+1);
			setMetadata("Label", col_montage_names[cc]);
		}
	}
}


print("----------------------DONE---------------------------");
// This macro transforms one image to match another based on a line drawn in each image
// User must draw the two lines/points in the same order so that fiducials will match
// The points/lines are drawn on a z-projection, but the original stacks are transformed
// So 4 image inputs are needed.

// First, one image is rotated so that the two lines are parallel
// Second, the image is translated so that the two points match
// Third, the stacks are concatenated

//Ask user for 4 images to use
//two for drawing lines / points
//two for concatenation
if (nImages <1) exit("No Stack Window Open"); 
setBatchMode(true);
allStackTitles=newArray(nImages);
for (i=0; i<nImages; i++) { 
	selectImage(i+1); //one based index
    if (nSlices>1) { 
    	allStackTitles[i]=getTitle(); 
    } 
}

Dialog.create("Select input"); 
Dialog.addMessage("This macro transforms one image to match another based on a line drawn in each image.\nThe user must draw the two lines/points in the same order so that fiducials will match.\nThe points/lines are drawn on a z-projection - Stable & Transform Image,but the \noriginal stacks are transformed - Concat Stable & Transform.\n----\nBefore starting, make sure lines or points are drawn in the same order on the first 2 images.\n----\n")
Dialog.addChoice("Stable Image", allStackTitles);
Dialog.addChoice("Transform Image", allStackTitles);
Dialog.addChoice("Concat Stable", allStackTitles);
Dialog.addChoice("Concat Transform", allStackTitles);
Dialog.show();
stableImage = Dialog.getChoice();
transformImage = Dialog.getChoice();
concatStable = Dialog.getChoice();
concatTransform = Dialog.getChoice();


//----------Get line ROI from each image
//image1
selectWindow(stableImage);
getDimensions(width, height, channels, slices, frames); //assume images have same dimensions
Roi.getCoordinates(xpoints, ypoints);
//IJ.log("("+xpoints[0]+","+ypoints[0]+") - ("+xpoints[1]+","+ypoints[1]+")");

//image2
selectWindow(transformImage);
Roi.getCoordinates(xpoints2, ypoints2);
//IJ.log("("+xpoints2[0]+","+ypoints2[0]+") - ("+xpoints2[1]+","+ypoints2[1]+")");

/*
//----------Find slope for each line
//image1 slope
slope1 = (ypoints[0]-ypoints[1])/(xpoints[0]-xpoints[1]);
//image2 slope
slope2 = (ypoints2[0]-ypoints2[1])/(xpoints2[0]-xpoints2[1]);
IJ.log(slope1 +"  __  "+slope2)
//----------Determine which way to rotate by minimizing angle
slopeDiff1 = slope1-slope2;
slopeDiff2 = slope2-slope1;
IJ.log(slopeDiff1 +"  __-__  "+slopeDiff2)
if(slope1<slope2){
	rad = slopeDiff1;
}else{
	rad = slopeDiff2;
}
theta = rad*180/PI;
IJ.log("Theta: "+theta);
*/

//----------Find angle for each line
//image1 angle
angle1 = atan2((ypoints[0]-ypoints[1]),(xpoints[0]-xpoints[1]));
//image2 angle
angle2 = atan2((ypoints2[0]-ypoints2[1]),(xpoints2[0]-xpoints2[1]));
//IJ.log(angle1 +"  __  "+angle2);

//----------Determine which way to rotate by minimizing angle
angleDiff1 = angle1-angle2;
angleDiff2 = angle2-angle1;
//IJ.log(angleDiff1 +"  __-__  "+angleDiff2)
if(angle1<angle2){
	angleRadians  = angleDiff1;
}else{
	angleRadians  = angleDiff2;
}
theta = angleRadians*180/PI;
IJ.log("Theta: "+theta);

//----------Rotate coords then get translation magnitude
//rotate around center of image, NOT origin (0,0)
//center at w/2,h/2
x=xpoints2[0];
y=ypoints2[0];
 		centerX = (width-1)/2.0;
        centerY = (height-1)/2.0;
        
        //double angleRadians = -theta/(180.0/Math.PI);
        ca = cos(angleRadians);
        sa = sin(angleRadians);
        tmp1 = centerY*sa-centerX*ca;
        tmp2 = -centerX*sa-centerY*ca;
        tmp3 = tmp1 - y*sa + centerX;
        tmp4 = tmp2 + y*ca + centerY;
	xs = x*ca + tmp3;
    ys = x*sa + tmp4;
    //IJ.log("("+xs+","+ys+")");
    translateX = xpoints[0] - xs;
	translateY = ypoints[0] - ys;
	IJ.log("tX: "+translateX);
	IJ.log("tY: "+translateY);

selectWindow(concatTransform);
run("Rotate... ", "angle="+theta+" grid=1 interpolation=Bilinear stack");
run("Translate...", "x="+translateX+" y="+translateY+" interpolation=None stack");
//concatStable = "mri-stack-2.tif";
//concatTransform = "mri-stack-3.tif";
IJ.log(concatStable);
IJ.log(concatTransform);
run("Concatenate...", "  title=[Concatenated Stacks] image1=["+concatStable+"] image2=["+concatTransform+"] image3=[-- None --]");
setBatchMode(false); 
/*
 * 
 * 
 * //make canvas bigger before translation so that none is clipped
bigWidth = width + (dist*2);
bigHeight = height + (dist*2);
run("Canvas Size...", "width="+bigWidth+" height="+bigHeight+" position=Center zero");





w=width;
h=height;
x=xpoints2[0]-((w-1)/2);
y=ypoints2[0]-((h-1)/2);
IJ.log("w: "+w+"   h: "+h)
IJ.log("x: "+x+"   y: "+y)
//newX0 = (xpoints2[0]-(w/2))*cos(theta) + (ypoints2[0]-(h/2))*sin(theta) + (w/2);
//newY0 = (ypoints2[0]-(h/2))*cos(theta) - (xpoints2[0]-(w/2))*sin(theta) + (h/2);
//newX0 = xpoints2[0]*cos(theta) + ypoints2[0]*sin(theta);
//newY0 = ypoints2[0]*cos(theta) - xpoints2[0]*sin(theta);
newX0 = x*cos(angleRadians) - y*sin(angleRadians) +((w-1)/2);
newY0 = x*sin(angleRadians) - y*cos(angleRadians) +((h-1)/2);
IJ.log("("+newX0+","+newY0+")");
translateX = xpoints[0] - newX0;
translateY = ypoints[0] - newY0;
IJ.log("tX: "+translateX);
IJ.log("tY: "+translateY);

/*
//figure out how far to move
dist0 = sqrt((xpoints2[0]-xpoints[0])*(xpoints2[0]-xpoints[0])+(ypoints2[0]-ypoints[0])*(ypoints2[0]-ypoints[0]));
dist1 = sqrt((xpoints2[1]-xpoints[1])*(xpoints2[1]-xpoints[1])+(ypoints2[1]-ypoints[1])*(ypoints2[1]-ypoints[1]));
dist = dist1+dist0+100;





// Explan plugin...
// 
// 
// 

import ij.*;
import ij.process.*;
import ij.gui.*;
import java.awt.*;
import ij.plugin.*;
import ij.plugin.frame.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import java.io.*;
import org.xml.sax.SAXException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;
import javax.xml.xpath.XPathExpressionException;

import javax.swing.filechooser.*;


public class SlideScanner_macro_batch_QIQ implements PlugIn {

	public void run(String arg) {
		//IJ.run("Close All");
		
		GenericDialog gd = new GenericDialog("New Image");
		gd.addChoice("Projection:",
                      new String[] {"Average Intensity","Max Intensity","Min Intensity","Sum Slices","Standard Deviation","Median"},
                      "Max Intensity");
		gd.addNumericField("Ch 1 Threshold Min: ", 0, 5);
		gd.addNumericField("Ch 1 Threshold Max: ", 65536, 5);
		gd.addNumericField("Ch 2 Threshold Min: ", 0, 5);
		gd.addNumericField("Ch 2 Threshold Max: ", 65536, 5);
		gd.showDialog();
		if (gd.wasCanceled()) return;
		String projection = gd.getNextChoice();
		int ch1threshmin = (int)gd.getNextNumber();
		int ch1threshmax = (int)gd.getNextNumber();
		int ch2threshmin = (int)gd.getNextNumber();
		int ch2threshmax = (int)gd.getNextNumber();
		//IJ.run("Z Project...", "projection=["+projection+"]");

		File dir = new File(IJ.getDirectory("Choose a Directory "));
		
		String processedPath = makeProcessedFolder(dir);
		
		File[] fileList = dir.listFiles();
		for(File collectionDir : fileList){
			if(collectionDir.getName().contains(".Collection")){
				File[] fileList2 = collectionDir.listFiles();
				for(File layerDir : fileList2){
					if(layerDir.getName().contains("Layer")){
						String path = layerDir.getPath() + File.separator;
						Document xmlDocument = getXmlDoc(path  + "Layer-source-metadata.xml");
						String[] xyVal = doXpath(xmlDocument);
						IJ.log("valX: "+xyVal[0]);
						IJ.log("valY: "+xyVal[1]);
						IJ.open(path + "CH0_Z.tif");
						IJ.open(path + "CH1_Z.tif");
						String macroArgs = projection+","+ ch1threshmin +","+ ch1threshmax+","+ ch2threshmin +","+ ch2threshmax;
						IJ.runMacroFile("QIQmacro_SlideScanner3.ijm",macroArgs);
						ImagePlus imp = WindowManager.getCurrentImage();
						IJ.saveAsTiff(imp,processedPath + collectionDir.getName() + "_X"+xyVal[0] + "Y"+xyVal[1] + "_" + layerDir.getName() + ".tif");
						IJ.saveAs(imp,"jpg",processedPath + collectionDir.getName() +"_X"+xyVal[0] + "Y"+xyVal[1] + "_"+ layerDir.getName()+ ".jpg");
						IJ.run("Close All");
						//break;
					}
				}
				//break;
			}
		}
		
		
		
	}
	
	String makeProcessedFolder(File mainDir){
		//get last directory and make processed folder
		String dir = mainDir.getPath();
		String processedPath = dir + File.separator + "Processed" + File.separator;
		//IJ.log(processedPath);
		
		try{
			File processedFile = new File(processedPath);
			if(!processedFile.exists() || !processedFile.isDirectory()){
				processedFile.mkdir();
			}
	
		}catch(Exception err){
			
		}
		return processedPath;

	}
	
	Document getXmlDoc(String filePath){
		DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = null;
		Document document = null;
		try {
			builder = builderFactory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();  
		}
		
		
		try {
			document = builder.parse(new FileInputStream(filePath));
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return document;
	}
	
	String[] doXpath(Document xmlDoc){
		XPath xPath =  XPathFactory.newInstance().newXPath();
		String selectorX = "//ImageOriginX/@value";
		String selectorY = "//ImageOriginY/@value";
		String xVal = null;
		String yVal = null;
		try {
			//read a string value
			xVal = xPath.compile(selectorX).evaluate(xmlDoc);
			yVal = xPath.compile(selectorY).evaluate(xmlDoc);
			//Node node = (Node) xPath.compile(expression).evaluate(xmlDocument, XPathConstants.NODE);
		} catch(XPathExpressionException e) {
            e.printStackTrace();
        }      
       	String[] xyVal = {xVal,yVal};
		return xyVal;
	}
	

}
//Get main folder with all other plate folders 
dir = getDirectory("Open Batch folder");

var list = getFileList(dir);	//get file list as array
Array.sort(list); 
for(i = 0; i < list.length; i++) {		//loop through each element in the 'list' array
	//  The following will be done  for every file in the folder
	if(File.isDirectory(dir+list[i]) && indexOf(dir+list[i],"aggregated_results")<0){	//If this file IS a directory...
		
		//Get plate name from the name of the root folder
		pname=replace(list[i],"/", "");

		//The results folder contains all of the worksheets that we need to process
		plateDir = dir+list[i];
		resultsDir = dir+list[i]+"results"+File.separator;
		aggregatedDir1 = dir+"aggregated_results\\";
		aggregatedDir = dir+"aggregated_results\\aggregated_results\\";

		//find the first .xls in the results folder
		var resultList = getFileList(resultsDir);	//get file list as array
		Array.sort(resultList); 
		fname="";
		for(j = 0; j < resultList.length; j++) {
			if(endsWith(resultList[j],".xls")){
				fname = resultList[j];
				break;
			}
		}
		//if(fname=""){continue;}
		resultsDir=replace(resultsDir,"/", "\\");
		plateDir=replace(plateDir,"/", "\\");
		aggregatedDir=replace(aggregatedDir,"/", "\\");
		print(resultsDir+fname);
		print(aggregatedDir1);
		if(!File.isDirectory(aggregatedDir1)){
			File.makeDirectory(aggregatedDir1);
			File.makeDirectory(aggregatedDir);
		}
		
		//fname=File.openDialog("Open Worksheet");
		run("custom yeast nuclear table jru v2", "min_nuc_vol=250 max_nuc_vol=2000 red_center_statistic=Avg red_shift_statistic=Avg min_red_multiplier=1.00000 max_red_multiplier=1.00000 open=["+resultsDir+fname+"]");
		//waitForUser("check");
		run("rename table jru v1", "windows=[Final Filtered Well_Avg] new=["+pname+"_Final Filtered Well_Avg.xls]");
		//waitForUser("check");

		run("close table jru v1", "table=[Volume Filtered_Avg]");
		//waitForUser("check");

		run("close table jru v1", "table=[Combined Table]");
		//waitForUser("check");

		run("rename table jru v1", "windows=[Volume Filtered] new=["+pname+"_volume_filtered.xls]");
		//waitForUser("check");

		run("heatmap jru v1", "windows=["+pname+"_Final Filtered Well_Avg.xls] x=col y=row intensity=green/surf");
		rename("green_heatmap");
		//waitForUser("check");

		//run("greenyellowred");
		run("heatmap jru v1", "windows=["+pname+"_Final Filtered Well_Avg.xls] x=col y=row intensity=count");
		//run("greenyellowred");
		rename("intensity_heatmap");
		//waitForUser("check");

		imageWindows = getList("image.titles");
		for(k = 0; k < imageWindows.length; k++) {
			selectWindow(imageWindows[k]);
			save(aggregatedDir+pname+"_"+imageWindows[k]+".tif");
			run("Close") ;
		}

		otherWindows = getList("window.titles");
		for(k = 0; k < otherWindows.length; k++) {
			if(otherWindows[k]!="Log"){ //the log window can't be saved
				selectWindow(otherWindows[k]);
				//saveAs("Text",aggregatedDir+pname+"_"+otherWindows[k]+".xls");
				run("export table jru v1", "table1=["+otherWindows[k]+"] format=xls(tab) save=["+aggregatedDir+pname+"_"+otherWindows[k]+".xls"+"]");
				run("Close") ;
			}			
		}

	}
}



import ij.*;
import ij.process.*;
import ij.gui.*;
import ij.gui.Roi;
import java.awt.*;
import ij.plugin.*;
import ij.plugin.frame.*;

import java.io.*;
import java.awt.Polygon;
import java.lang.*;

//This is the macro Richard wrote for cropping out stem cells

public class Sarah_bone_crop2 implements PlugIn {
	public void run(String arg) {
		File dir = new File(IJ.getDirectory("Choose a Directory "));
		
		GenericDialog gd = new GenericDialog("Number of points per cell");
      		 gd.addNumericField("Points: ", 4, 0);
		gd.showDialog();
		int points = (int)gd.getNextNumber();
		
		//String processedPath = makeProcessedFolder(dir);
		
		File[] fileList = dir.listFiles();
		for(File zip_file : fileList){
			String file_name = zip_file.getName();
			if(!file_name.endsWith(File.separator) && file_name.endsWith(".zip")){
				IJ.open(zip_file.getPath());
				// look for - in name, then take number before (bone) and after (tile)
				String trim = file_name.replaceAll("\\s+"," ");
				String[] name_array = trim.split(" ");
				//String[] number_array = name_array[1].split("-");
				String bone_number = name_array[1];
				String end_string = name_array[4];
				String[] end_array = end_string.split("\\.");
				String tile_number =  end_array[0];//String tile_number="jjj";//
IJ.log(file_name);
IJ.log(trim);
IJ.log("bone# "+bone_number);
IJ.log("tile# "+tile_number);
IJ.log("end "+end_string);
IJ.log("tile# "+tile_number);
//				IJ.log("bone: "+bone_number);
//				IJ.log("tile: "+tile_number);


				File[] fileList2 = dir.listFiles();
				for(File image_file : fileList2){
					String image_name = image_file.getName();
					IJ.log(image_name);
					if( image_name.indexOf("bone "+bone_number)>=0 && image_name.indexOf("tile "+tile_number)>=0 && image_name.indexOf(".tif")>=0 ){
						RoiManager roim = RoiManager.getInstance();
						
						//every 3rd or 4th roi is the stem cell... loop through
						int count = roim.getCount();
						for(int i=0; i<count; i+=points){
							int cellnum = i/points+1;
							Roi roi = roim.getRoi(i);	//get first roi
							PolygonRoi pRoi = (PolygonRoi)roim.getRoi(i);	//get first roi
							Polygon pgon = pRoi.getPolygon();
							int x = pgon.xpoints[0];
							int y = pgon.ypoints[0];
							int z = roi.getZPosition();
							//int t = roi.getTPosition();
							IJ.log(""+x);
							IJ.log(""+y);
							IJ.log(""+z);
							IJ.log("FOUND:");
							IJ.log(image_file.getPath());
							int zbegin = z-3;
							int zend = z+3;
							int xbegin = x-74;
							//int xend = x+75;
							int ybegin = y-74;
							//int yend = y+75;
							IJ.run("Bio-Formats Importer", "open=["+image_file.getPath()+"] color_mode=Composite crop specify_range view=Hyperstack stack_order=XYCZT c_begin=1 c_end=4 c_step=1 z_begin="+zbegin+" z_end="+zend+" z_step=1 x_coordinate_1="+xbegin+" y_coordinate_1="+ybegin+" width_1=150 height_1=150");
							ImagePlus imp = WindowManager.getCurrentImage();
							imp.setC(1);
							IJ.setMinAndMax(0, 400);
							imp.setC(2);
							IJ.setMinAndMax(0, 400);
							imp.setC(3);
							IJ.setMinAndMax(0, 3500);
							imp.setC(4);
							IJ.setMinAndMax(0, 1500);
	
							//save in same folder
							IJ.save(dir+File.separator+file_name+"_crop_"+cellnum+".tif");
							IJ.run("Close All");
						}
						//reset roi manager
						roim.reset();
						
						
					}
				}
				
			}
		}
		
	}

	
	
}

import ij.*;
import ij.process.*;
import ij.gui.*;
import java.awt.*;
import ij.plugin.*;
import ij.plugin.frame.*;


public class Resume_Macro_Exceptions implements PlugIn {
	public static String pgLog = "RESUME_MACRO_EXCEPTIONS says: ";

	public void run(String arg) {
		
		doMacro(0);
		doLog("Complete!! :)");
		
	}
	
	public void doMacro(int i){

		doLog("First:("+i+")");
		try{
			//run macro here
			IJ.runMacroFile("Batch_OpenMeasureSave_SLJCJS_v2.ijm");
		} catch (Throwable e){
			//if macro fails, run it again!
			doLog("Caught exception --------------------------  --  --  ------- Starting "+i);
			if(i<3){
				doMacro(i+1);
			}
		}

	}

	public void doLog(String text){
		IJ.log(pgLog+ text);
	}

}

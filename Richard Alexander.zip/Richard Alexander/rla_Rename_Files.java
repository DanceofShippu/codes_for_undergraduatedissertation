import ij.*;
import ij.process.*;
import ij.gui.*;
import java.awt.*;
import ij.plugin.*;
import ij.plugin.frame.*;
import java.io.*;

public class rla_Rename_Files implements PlugIn {

	public void run(String arg) {
		String replace_this = ".tif_t-";
		String with_this = ".tif_t-0";

		//String file_separator = File.separator;
	
		File dir = new File(IJ.getDirectory("Choose a Directory "));
		File[] fileList = dir.listFiles();

		
		 
		for (int i = 0; i < fileList.length; i++) {
		 	IJ.log("orig:    " + dir.getAbsolutePath()
							+ "\\" + fileList[i]);
		 
			File oldFile = fileList[i];
			int index = oldFile.getName().indexOf(replace_this);
			
			if(!oldFile.isDirectory() && index >= 0){//  && index <5
				File newFile = new File(dir + "\\" +oldFile.getName().replaceFirst(replace_this, with_this)); //must escape the "." character
			 	IJ.log("new:      " + newFile);
				
				boolean isFileRenamed = oldFile.renameTo(newFile);
			 
				if (isFileRenamed)
					IJ.log("......renamed");
				else
					IJ.log("......Error");
			}else{
				IJ.log("....file index not found....");
			}
			
		}
	}

}

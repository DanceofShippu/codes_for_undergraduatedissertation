//To create a new GUI, Rename this file "new_filename", then find and replace all instences of
//"AndrewNPC_overlap_gui" with "new_filename".

import ij.*;
import ij.io.*;
import ij.process.*;
import ij.gui.*;
import java.awt.*;
import ij.plugin.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.*;
import ij.plugin.frame.RoiManager;
import ij.measure.ResultsTable;
import ij.plugin.filter.Analyzer;

public class AndrewNPC_overlap_gui 	extends JPanel implements PlugIn , ActionListener{
    static private final String newline = "\n";
    JButton clearButton, finishButton, processButton;
    JTextField rangeBeginText, rangeEndText;
    JTextArea log;
    JFileChooser fc;
    String CellsFilePath, FidFilePath, Directory, SaveName, NameSub;
    Boolean clearTextFlag = true;
    int count = 0;
    String[] logListBegin = new String[100];
    String[] logListEnd = new String[100];
    File[] files;
    
    public AndrewNPC_overlap_gui() {
        super(new BorderLayout());

        //Create the log first, because the action listeners
        //need to refer to it.
        log = new JTextArea(15,15);
        log.setMargin(new Insets(5,5,5,5));
        log.setEditable(false);
	log.setLineWrap(true);
	log.setWrapStyleWord(true);
	log.setText("Instructions:"+newline+newline+"In the text box above, enter the Noise Tolerance parameter to be used in Find Maxima. On your image, draw an ROI around the cell of interest, then click ''Process''."+newline+newline+"Repeat drawing ROIs and clicking process until done. Then click ''Finish'' to save the ROIs and the data in the Results table to the new ''Processed'' folder located in the current image's directory.");
        JScrollPane logScrollPane = new JScrollPane(log);

        //Create a file chooser
        fc = new JFileChooser();
        fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

        //Uncomment one of the following lines to try a different
        //file selection mode.  The first allows just directories
        //to be selected (and, at least in the Java look and feel,
        //shown).  The second allows both files and directories
        //to be selected.  If you leave these lines commented out,
        //then the default mode (FILES_ONLY) will be used.
        //
        //fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        //fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);

        //Create the clear button.  
        clearButton = new JButton("Clear Log");
        clearButton.addActionListener(this);

        //Create the save range button.
        finishButton = new JButton("Finish");
        finishButton.addActionListener(this);

      //Create the process button.  
        processButton = new JButton("Process");
        processButton.addActionListener(this);

	//Create new JTextField
	rangeBeginText = new JTextField("125",4);
	rangeEndText = new JTextField("End Range",7);
        
        //For layout purposes, put the buttons in a separate panel
        JPanel buttonPanel = new JPanel(); //use FlowLayout
        buttonPanel.add(finishButton);
	 	buttonPanel.add(rangeBeginText);
		//buttonPanel.add(rangeEndText);
	
    	//buttonPanel.add(clearButton);
    	buttonPanel.add(processButton);

        //Add the buttons and the log to this panel.
        add(buttonPanel, BorderLayout.PAGE_START);
        add(logScrollPane, BorderLayout.CENTER);
    }

    public void actionPerformed(ActionEvent e) {

        //Handle finish button action.
        if (e.getSource() == finishButton) {
			ImagePlus imp=WindowManager.getCurrentImage();
			
        	
			//get last directory and make processed folder
			String dir = IJ.getDirectory("image");
			String processedPath = dir + "processed" + File.separator;
			//IJ.log(processedPath);
			
			try{
				File processedFile = new File(processedPath);
				if(!processedFile.exists() || !processedFile.isDirectory()){
					processedFile.mkdir();
				}
			
				String title = imp.getShortTitle();
	
	        	//Deselect, save ROIs, and measure all
	        	RoiManager roiMgr = RoiManager.getInstance2();
	        	roiMgr.deselect();
	        	roiMgr.runCommand("Save", processedPath + title+".zip");
	
	        	//Clear results table and save all measurements
	        	IJ.run("Clear Results");
	        	//ResultsTable rTable = roiMgr.multiMeasure(imp);
	        	roiMgr.runCommand("Measure");
	        	ResultsTable rTable = Analyzer.getResultsTable();
	        	rTable.save(processedPath +title +"_results.xls");
	
	            //refresh Roi Manager
	            roiMgr.runCommand("Delete");
		
			}catch(Exception err){
				
			}
            
        //Handle process button action
        }else if (e.getSource() == processButton) {
        String noise_string= rangeBeginText.getText();
        	int noise_param = Integer.parseInt(noise_string);
			IJ.runMacroFile("AndrewNPC_semi_overlap",noise_string);
        }
 
    }


//Function to delete slices
  public void deleteSlices(){
	for(File f : files){
		String current =  f.getPath();
		if (!f.getPath().endsWith("/") & f.getPath().endsWith(".tif")){
			ij.IJ.open(f.getPath());
			ImagePlus imp = WindowManager.getCurrentImage();
			ImageStack stack = imp.getImageStack();
			for(int j=0; j<count; j++){
				int first = Integer.parseInt(logListBegin[j]);
				int last = Integer.parseInt(logListEnd[j]);
				int count1 = 0;
				for (int i=first; i<=last; i++) {
					if ((i-count1)>stack.getSize())
						break;
					stack.deleteSlice(i-count1);
					count1++;
				}
			}
			String name = f.getName();
			String direct = f.getParent();
			log.append(direct + "\\ds_"+ name+ newline);
			IJ.save(direct + "\\ds_"+ name);
			imp.close();
		}
	}	
  }




    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event dispatch thread.
     */
    private static void createAndShowGUI() {
        //Create and set up the window.
        JFrame frame = new JFrame("New Title");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        //Add content to the window.
        frame.add(new AndrewNPC_overlap_gui());

        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }

    public static void mainrun() {
        //Schedule a job for the event dispatch thread:
        //creating and showing this application's GUI.
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                //Turn off metal's use of bold fonts
                UIManager.put("swing.boldMetal", Boolean.FALSE); 
                createAndShowGUI();
                //IJ.log("\\Clear");
                //IJ.log("Count,Noise Tolerance (Find Maxima),ROI Type,ROI Bounds x,ROI Bounds y,ROI Bounds width,ROI Bounds height,Image Name,Full Path");
            }
        });
    }
    public void run(String arg) {
		//IJ.showMessage("My_Plugin","Hello world!");
		AndrewNPC_overlap_gui.mainrun();
	}
}

// get folder
dir = getDirectory("Choose a Directory");
fileList = getFileList(dir);

//select template file (predrug)
Dialog.create("Select File");
Dialog.addChoice("Select template file (predrug)", fileList); 
Dialog.show();
template = Dialog.getChoice();

//check if folder "aligned" exsists, and create if not
var newFolder = dir+"aligned"+File.separator;
if(!File.isDirectory(newFolder)){
	File.makeDirectory(newFolder);
}

//open template file (predrug)
//average project
//template = "AVG_MBE1 anesthesia predrug 24-1-2017_XY1485296756_Z0_T0000_C0.tif";
//avgTemplate = "AVG_MBE1 anesthesia predrug 24-1-2017_XY1485296756_Z0_T0000_C0.tif";

setBatchMode(true);


//open template file (predrug)
open(dir+template);
//average project
selectWindow(template);
run("Z Project...", "projection=[Average Intensity]");
avgTemplate = "avgTemplate";
rename(avgTemplate);

//loop through other image stacks that aren't folders and are not the tempolate file
for(i=0; i<fileList.length; i++){
	if(fileList[i] == template || endsWith(fileList[i],"/")){
		//don't align template file
		//print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>"+fileList[i]);
	}else{		
		roiManager("reset");
		
		//open target file (drugged)
		//average project
		target = fileList[i];//"MBE Post injection anethsia 24-1-2016_XY1485303289_Z0_T0000_C0.tiff"; //get target from fileList
		print("-------------------------------------------------------"+target);
		open(dir+target);
		selectWindow(target);
		run("Z Project...", "projection=[Average Intensity]");
		avgTarget = "avgTarget";
		rename(avgTarget);
		
		//run SIFT or MOPS on averaged images
		run("Extract SIFT Correspondences", "source_image=["+avgTemplate+"] target_image=["+avgTarget+"] initial_gaussian_blur=1.60 steps_per_scale_octave=3 minimum_image_size=64 maximum_image_size=1024 feature_descriptor_size=4 feature_descriptor_orientation_bins=8 closest/next_closest_ratio=0.92 filter maximal_alignment_error=25 minimal_inlier_ratio=0.05 minimal_number_of_inliers=7 expected_transformation=Similarity");
		
		//select target image and add to ROI manager
		selectWindow(avgTarget);
		roiManager("Add");
		
		
		//test with average
		//run("Landmark Correspondences", "source_image=[AVG_MBE Post injection anethsia 24-1-2016_XY1485303289_Z0_T0000_C0.tif] template_image=[AVG_MBE1 anesthesia predrug 24-1-2017_XY1485296756_Z0_T0000_C0.tif] transformation_method=[Least Squares] alpha=1 mesh_resolution=32 transformation_class=Similarity interpolate show_matrix");
		//selectWindow("MBE Post injection anethsia 24-1-2016_XY1485303289_Z0_T0000_C0-1.tiff");
		
		//open real stack, duplicate slice, run landmark corresp, loop through stack
		selectWindow(target);
		for(j=0; j<nSlices; j++){
			showStatus("Transforming")
			showProgress(j/nSlices);
			selectWindow(target);
			run("Duplicate...", "title=dup");
			selectWindow("dup");
			roiManager("Select", 0);
			run("Landmark Correspondences", "source_image=dup template_image=["+avgTemplate+"] transformation_method=[Least Squares] alpha=1 mesh_resolution=32 transformation_class=Similarity interpolate");
			selectWindow("dup");
			close();
			selectWindow("Transformeddup");
			rename("Transformeddup"+j);
			selectWindow(target);
			run("Next Slice [>]");
			
			/*
			run("Duplicate...", "title=dup");
			roiManager("Select", 0);
			run("Landmark Correspondences", "source_image=dup template_image=[AVG_MBE Post injection anethsia 24-1-2016_XY1485303289_Z0_T0000_C0.tif] transformation_method=[Least Squares] alpha=1 mesh_resolution=32 transformation_class=Similarity interpolate");
			close();
			run("Landmark Correspondences", "source_image=dup template_image=[AVG_MBE1 anesthesia predrug 24-1-2017_XY1485296756_Z0_T0000_C0.tif] transformation_method=[Least Squares] alpha=1 mesh_resolution=32 transformation_class=Similarity interpolate");
			rename("Transformeddup"+j);
			*/
		}
		
		
		
		run("Images to Stack", "name=Stack title=Transformeddup use");
		
		//save the image and close it
		newName = "aligned_"+target; print(newName);
		rename(newName);
		save(newFolder+newName);
		close(newName);
		
		//close other images
		close("avgTarget");
		close("target");
		
		//remove selection from avgTemplate
		selectWindow(avgTemplate);
		run("Select None");
	}
}
run("Close All");
setBatchMode(false);
showStatus("Done");

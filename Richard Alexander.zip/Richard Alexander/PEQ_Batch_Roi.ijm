//	This maro takes a 2 channel image, makes a mask from CH2, then measures CH1

run("Set Measurements...", "area mean standard integrated display redirect=None decimal=9");

var dir = getDirectory("Choose a Directory ");	//get directory

var list = getFileList(dir);			//get file list as array
IJ.log("Processing: "+list.length);

 if (isOpen("Results")) { 
       selectWindow("Results"); 
       run("Close"); 
   } 

 if (isOpen("ROI Manager")) { 
       selectWindow("ROI Manager"); 
       run("Close"); 
   } 

for(i = 0; i < list.length; i++) {		//loop through each element in the 'list' array
	IJ.log(i+"   "+dir+list[i]);
	if(!File.isDirectory(dir+list[i])){	//If this file is NOT a directory...
		open(dir+list[i]);		//open the image

		run("Duplicate...", "title=MASK duplicate channels=2");
		run("Convert to Mask", "method=Default background=Dark black");
	
		run("Analyze Particles...", "size=4-Infinity circularity=0.00-1.00 show=Nothing exclude add");

		selectWindow(list[i]);		//measure original image
	
		roiManager("Show None");
		roiManager("Show All");
	
		var numRois = roiManager("count");
		var roiIndexes = newArray(numRois);
		for(var j=0; j<numRois; j++){
			roiIndexes[j] = j;
		}
		roiManager("Select",roiIndexes);
		roiManager("Measure");
	
		run("Close All");
		roiManager("Deselect");
		roiManager("Delete");
	}
}
saveAs("Results", dir+"PEQ_BatchRoi_Results.csv");

selectWindow("Results"); 
run("Close"); 
selectWindow("ROI Manager"); 
run("Close"); 


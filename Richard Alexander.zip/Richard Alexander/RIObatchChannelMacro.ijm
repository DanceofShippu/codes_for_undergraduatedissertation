run("Make Composite", "display=Composite");
Stack.setChannel(1);
run("Red");
Stack.setChannel(3);
run("Blue");
Stack.setChannel(4);
run("Magenta");

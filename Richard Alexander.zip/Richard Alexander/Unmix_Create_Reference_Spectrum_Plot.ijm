//Created 2017-01-24 by Richard Alexander for the Stowers Institute for Medical Research

Dialog.create("X-axis scale");
 Dialog.addNumber("Min:", 415.00000);
 Dialog.addNumber("Max:", 690.00000);
 Dialog.show();
min = Dialog.getNumber();
max = Dialog.getNumber();

dir = getDirectory("Choose a Directory ");
list = getFileList(dir);
Dialog.create("Add Spectra");
for (i=0; i<list.length; i++) {
	if(!File.isDirectory(dir+list[i])){
		Dialog.addCheckbox(list[i], true);
	}	
}
Dialog.show();
for (i=0; i<list.length; i++) {
	if(!File.isDirectory(dir+list[i])){
		if(Dialog.getCheckbox()){
			open(dir+list[i]);
			run("create spectrum jru v1", "spectrum=Avg");
		}
	}	
}

run("combine all trajectories jru v1", "combine_all_series series_to_combine=1 number_of_plots=2");
run("normalize trajectories jru v1", "normalization=Integral");
run("traj rescale x jru v1", "x_min="+min+" x_max="+max);
/*
selectWindow("488 autofluor refernce.lsm");
run("create spectrum jru v1", "spectrum=Avg");
selectWindow("Dapi reference.lsm");
run("create spectrum jru v1", "spectrum=Avg");

selectWindow("epcr 647 reference.lsm");
run("create spectrum jru v1", "spectrum=Avg");
selectWindow("ncad rfp reference.lsm");
run("create spectrum jru v1", "spectrum=Avg");

run("combine all trajectories jru v1", "combine_all_series series_to_combine=1 number_of_plots=2");


run("normalize trajectories jru v1", "normalization=Max");


run("traj rescale x jru v1", "x_min="+min+" x_max="+max);
*/
//To create a new GUI, Rename this file "new_filename", then find and replace all instences of
//"AndrewNPC_overlap_gui" with "new_filename".

import ij.*;
import ij.io.*;
import ij.process.*;
import ij.gui.*;
import java.awt.*;
import ij.plugin.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.*;
import ij.plugin.frame.RoiManager;
import ij.measure.ResultsTable;
import ij.plugin.filter.Analyzer;

public class RLA_plugin_slidescanner_select_roi	extends JPanel implements PlugIn , ActionListener{
    static private final String newline = "\n";
    JButton clearButton, finishButton, processButton;
    JTextField rangeBeginText, rangeEndText;
    JTextArea log;
    JFileChooser fc;
    String CellsFilePath, FidFilePath, Directory, SaveName, NameSub;
    Boolean clearTextFlag = true;
    int count = 0;
    String[] logListBegin = new String[100];
    String[] logListEnd = new String[100];
    File[] files;
    
    public RLA_plugin_slidescanner_select_roi() {
        super(new BorderLayout());

        //Create the log first, because the action listeners
        //need to refer to it.
        log = new JTextArea(15,15);
        log.setMargin(new Insets(5,5,5,5));
        log.setEditable(false);
	log.setLineWrap(true);
	log.setWrapStyleWord(true);
	log.setText("Instructions:"+newline+newline+"Open an image and the corresponding ROI set."+newline+newline+"Draw one or more ROIs on the image, then click 'Process'. The plugin will make a new ROI set that ONLY contains ROIs that are inside the drawn selection."+newline+newline+"To work on a new image, close all images and clear the ROI manager, then open a new image and the corresponding ROI set." );
        JScrollPane logScrollPane = new JScrollPane(log);

        //Create a file chooser
        fc = new JFileChooser();
        fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

        //Uncomment one of the following lines to try a different
        //file selection mode.  The first allows just directories
        //to be selected (and, at least in the Java look and feel,
        //shown).  The second allows both files and directories
        //to be selected.  If you leave these lines commented out,
        //then the default mode (FILES_ONLY) will be used.
        //
        //fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        //fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);

//        //Create the clear button.  
//        clearButton = new JButton("Clear Log");
//        clearButton.addActionListener(this);
//
//        //Create the save range button.
//        finishButton = new JButton("Finish");
//        finishButton.addActionListener(this);

      //Create the process button.  
        processButton = new JButton("Process");
        processButton.addActionListener(this);
//
//	//Create new JTextField
//	rangeBeginText = new JTextField("125",4);
//	rangeEndText = new JTextField("End Range",7);
        
        //For layout purposes, put the buttons in a separate panel
        JPanel buttonPanel = new JPanel(); //use FlowLayout
//        buttonPanel.add(finishButton);
//	 	buttonPanel.add(rangeBeginText);
		//buttonPanel.add(rangeEndText);
	
    	//buttonPanel.add(clearButton);
    	buttonPanel.add(processButton);

        //Add the buttons and the log to this panel.
        add(buttonPanel, BorderLayout.PAGE_START);
        add(logScrollPane, BorderLayout.CENTER);
    }

    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == processButton) {
        	testROIs();
        }
 
    }


	public void testROIs(){
		// test whether each ROI is inside the selection
		// if not, delete it
		ImagePlus imp = IJ.getImage(); 
		String title = imp.getTitle();
		FileInfo info = imp.getOriginalFileInfo();
		String dir = info.directory;
		
		RoiManager roim = RoiManager.getInstance();
		int num_roi = roim.getCount();
		Roi selection_roi = imp.getRoi();
		for(int i=num_roi-1; i>=0; i--){
			Roi this_roi = roim.getRoi(i);
			Rectangle rect = this_roi.getBounds();
			Double xPos = rect.getX();
			Double yPos = rect.getY();
			if(!selection_roi.contains(xPos.intValue(), yPos.intValue())){
				roim.select(i);
				roim.runCommand("Delete");
			}
		}
		
		//save user ROI
		roim.addRoi(selection_roi);
		String roi_name = roim.getName(roim.getCount()-1);

		//save all ROIs to file
		roim.runCommand("Deselect");
		IJ.log(dir+title+"_ROI_"+roi_name+".zip");
		roim.runCommand("Save",dir+title+"_ROI_"+roi_name+".zip");
	}




    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event dispatch thread.
     */
    private static void createAndShowGUI() {
        //Create and set up the window.
        JFrame frame = new JFrame("New Title");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        //Add content to the window.
        frame.add(new RLA_plugin_slidescanner_select_roi());

        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }

    public static void mainrun() {
        //Schedule a job for the event dispatch thread:
        //creating and showing this application's GUI.
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                //Turn off metal's use of bold fonts
                UIManager.put("swing.boldMetal", Boolean.FALSE); 
                createAndShowGUI();
                //IJ.log("\\Clear");
                //IJ.log("Count,Noise Tolerance (Find Maxima),ROI Type,ROI Bounds x,ROI Bounds y,ROI Bounds width,ROI Bounds height,Image Name,Full Path");
            }
        });
    }
    public void run(String arg) {
		//IJ.showMessage("My_Plugin","Hello world!");
		RLA_plugin_slidescanner_select_roi.mainrun();
	}
}

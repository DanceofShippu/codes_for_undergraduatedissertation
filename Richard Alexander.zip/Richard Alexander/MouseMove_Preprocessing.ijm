//Preprocessing macro, made by Dr. Lining JU
run("Close All");
print("\\Clear");
//Indiate the video files locations
HomeDirectory=getDirectory("Choose Source Directory");
list=getFileList(HomeDirectory);
//Reset the background color
run("Colors...", "background=white");
//Setup the stepwise analysis 
framestep=5000;
framerange=20000;
//Welcome message
Msg="Start batch preprocessing...";
print(Msg);

for (k=0;k<list.length;k++)
{
	ix=indexOf(list[k],"empty");
	if (ix>0)//Check whether this is a background video
	{
		Refname=list[k];
		Expname= substring(Refname,0,ix-1)+".avi";
		//Setup the file paths
		Refpath=HomeDirectory+File.separator+Refname;
		Exppath=HomeDirectory+File.separator+Expname;
		
		Msg="Start processing "+Expname+"...";
		print(Msg);
		
		for(i=1;i<=framerange;i=i+framestep)
		{
			fstart=i;
			fend=minOf(i+framestep-1,framerange);
			
			//////////////////////////////////////////////////////////////////
			//Import the last image of background avi video
			run("AVI...", "select=[&Refpath] use convert");
			N=nSlices;
			close();
			run("AVI...", "select=[&Refpath] first=&N last=&N use convert");
			
			//Import the experiment avi video and select frame numbers
			run("AVI...", "select=[&Exppath] first=&fstart last=&fstart use convert");
			//Make a stack for alignment
			run("Concatenate...", "  title=[Concatenated Alignment] image1=&Expname image2=&Refname image3=[-- None --]");
			//Image binarization
			setOption("BlackBackground", false);
			run("Make Binary", "method=Minimum background=Light thresholded remaining black");
			//run("Auto Threshold", "method=Minimum white stack");
			//Align the experiment video with the background video
			run("StackReg", "transformation=[Rigid Body]");
			//Import the experiment avi video and select frame numbers
			run("AVI...", "select=[&Exppath] first=&fstart last=&fend use convert");
			//Alignment with the 1st image as the background 
			run("Concatenate...", "  title=[Concatenated Stacks] image1=[Concatenated Alignment] image2=[&Expname] image3=[-- None --]");
			run("Delete Slice");
			//Bin the videos
			run("Bin...", "x=2 y=2 z=1 bin=Average");
			//Automatically find the boundary edge based on the 1st image. 
			//The coordinates of the center should be varied if different open field is used.
			doWand(130, 130, 90.0, "Legacy");
			run("Auto Threshold", "method=Minimum white stack");
			//Clear outer area and leave the arena and the mouse.
			run("Clear Outside", "stack");
			
			//Delete ROI
			run("Select None");
			//Remove the first slice
			run("Delete Slice");
			//Polish the stack
			run("Erode", "stack");
			//Smooth the tracked object
			run("Minimum...", "radius=4 stack");
			//Restore to the original size
			run("Dilate", "stack");
			
			j=1;
			while (j<=nSlices)
			{
				setSlice(j);
				getRawStatistics(count, mean, min, max, std);
				if(min==255)
					{
						run("Delete Slice");
					}
					else
					j++;		
			}
			//Run the tracking and save the result file
			dotIndex = indexOf(Expname, ".");
			Expbody = substring(Expname, 0, dotIndex)+"_"+toString(fstart)+"-"+toString(fend); 
			//Savename=Titlebody+"_trackresults.txt";
			SaveDatapath=HomeDirectory+File.separator+"TkResults_"+Expbody+".txt";
			call("MTrack2_.setProperty","showPathLengths","false"); 
			call("MTrack2_.setProperty","showLabels","false"); 
			call("MTrack2_.setProperty","showPositions","false"); 
			run("MTrack2 ", "minimum=20 maximum=1000 maximum_=10000 minimum_=5 save show save=[&SaveDatapath]");
			//Save the trajectory file
			selectWindow("Paths");
			//Savename=Titlebody+"_traj.jpg";
			SaveTrajpath=HomeDirectory+File.separator+"Traj_"+Expbody+".jpg";
			saveAs("Jpeg", SaveTrajpath);
			selectWindow("Concatenated Stacks labels");
			//Savename=Titlebody+"_traj.gif";
			SaveTrajpath=HomeDirectory+File.separator+"Traj_"+Expbody+".tif";
			saveAs("Tiff", SaveTrajpath);
			run("Close All");
			Msg=Expname+" Finished frames: "+ toString(fend)+"/"+toString(framerange);
			print(Msg);
		}
		Msg=Expname+" completed!\n";
		print(Msg);
	}
}
//Print the final message
Msg="All files in the directory are completed!\n";
print(Msg);
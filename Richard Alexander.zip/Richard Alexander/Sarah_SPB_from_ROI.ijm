//  This macro measures the sum of SPB using a list of points from ROI Manager.
//  A person will manually select the center of the SPB with the point selection tool.
//  Then add the point to ROI manager.
//  The macro takes the list of points, measures the sum intensity and outputs a results table.
//  Measurement is performed prebleach and post bleach
//  The results are saved in the same folder with the same name as the original (.txt).
//  ROIs are also saved in the same folder (.zip)

setBatchMode(true);
dir = getInfo("image.directory");
origTitle = getTitle();
//IJ.log(dir + "....."+origTitle);
  
  n = roiManager("count");
  getDimensions(width, height, channels, slices, frames)
for (i=0; i<n; i++) {
	roiManager("select", i);
	Stack.getPosition(channel, slice, frame) 
	Roi.getCoordinates(xpoints, ypoints);
	x=xpoints[0];
	y=ypoints[0];
	//IJ.log(x+","+y);
	//makeRectangle(x, y, width, height);
	doMeasure(floor(x),floor(y),slice,i);
}


function doMeasure(x,y,slice,row){
	//IJ.log(x+","+y);
	count = 0;
	sum1 = 0;
	sum2 = 0;
	//makeRectangle(x, y, width, height);
	//get 3x3 pixels in slice before and after photobleaching
	for(s=0; s<=1; s++){
		setSlice(slice+s*14);  //slice+0 is original... slice+14 is after bleach
		for(j=x-1; j<=x+1; j++){
			for(k=y-1; k<=y+1; k++){
				if(j>0 && j<width && k>0 && k<height ){ //&& s>0 && s<=slices
					if(s==0){
						count = count +1;
						sum1 = sum1 + getPixel(j,k);
					}else{
						sum2 = sum2 + getPixel(j,k);
					}
					
				}
			}
		}
	}
	setResult("Area",  row, count);
	setResult("Sum1",  row, sum1);
	setResult("Sum2",  row, sum2);
}


  
  updateResults();

  	//save ROIs
	roiManager("Deselect");
	path = dir + File.separator + origTitle + "_ROI.zip";
	roiManager("Save", path);

  	//save the results
	path = dir + File.separator + origTitle + "_results.txt";
	saveAs("Results", path);

		
  setBatchMode(false); // displays the stack
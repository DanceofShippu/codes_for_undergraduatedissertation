//To create a new GUI, Rename this file "new_filename", then find and replace all instances of
//"aGui_test" with "new_filename".

import ij.*;
import ij.io.*;
import ij.process.*;
import ij.gui.*;
import java.awt.*;
import ij.plugin.*;
import ij.plugin.frame.*;
import ij.measure.ResultsTable;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.*;

public class RLA_Wahid_Yeast_GUI 	extends JPanel implements PlugIn , ActionListener{
    static private final String newline = "\n";
    JButton button_tostack, button_all, button_green, button_red, button_half, button_undetermined, button_save, button_folderresults;
    //JTextField rangeBeginText, rangeEndText;
    JTextArea log;
    //JFileChooser fc;
    //String CellsFilePath, FidFilePath, Directory, SaveName, NameSub;
    //Boolean clearTextFlag = true;
    //int count = 0;
    //String[] logListBegin = new String[100];
    //String[] logListEnd = new String[100];
    //File[] files;
	String origDir, newDir, imgName;
	ImagePlus imp;
	RoiManager roiMgr;
	ResultsTable resultTbl;
   // CalcDistance CalcDist = new CalcDistance();
    
    public RLA_Wahid_Yeast_GUI() {
        super(new BorderLayout());

        //Create the log first, because the action listeners
        //need to refer to it.
        log = new JTextArea(15,20);
        log.setMargin(new Insets(5,5,5,5));
        log.setEditable(false);
	log.setLineWrap(true);
	log.setWrapStyleWord(true);
	log.setText("Instructions: \nOpen the 3 images in ImageJ. Use the 'Images to Stack' button to create a stack, as well as initialize variables for saving. Place multipoint selections on the current slice, then categorize it using a button (eg Green, Red). Do this for each slice, then click 'Save All' to save both the stack and the ROI set. Then open the next images and repeat.\n\nWhen you are done with the last images in a folder, after clicking 'Save All', click 'Get Folder Results' to aggregate the results.\n\n\nImportant: \nLeave the results table open throughout. That way all results will be aggregated into the last results table (but also saved incrementally along the way).");
        JScrollPane logScrollPane = new JScrollPane(log);

        //Create a file chooser
        //fc = new JFileChooser();
        //fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

        //Uncomment one of the following lines to try a different
        //file selection mode.  The first allows just directories
        //to be selected (and, at least in the Java look and feel,
        //shown).  The second allows both files and directories
        //to be selected.  If you leave these lines commented out,
        //then the default mode (FILES_ONLY) will be used.
        //
        //fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        //fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);

        //Create the button. 
        button_tostack = new JButton("Images to Stack");
        button_tostack.addActionListener(this);
		
		//Create the button.   
        button_all = new JButton("All");
        button_all.addActionListener(this);
		
        //Create the button.   
        button_green = new JButton("Green");
        button_green.addActionListener(this);

		//Create the button.  
        button_red = new JButton("Red");
        button_red.addActionListener(this);
		
		//Create the button.  
        button_half = new JButton("Half");
        button_half.addActionListener(this);
		
		//Create the button.  
        button_undetermined = new JButton("Undetermined");
        button_undetermined.addActionListener(this);
		
		//Create the button.  
        button_save = new JButton("Save All");
        button_save.addActionListener(this);
		
		//Create the button.  
        button_folderresults = new JButton("Get Folder Results");
        button_folderresults.addActionListener(this);

		//Create new JTextField
		//rangeBeginText = new JTextField("Begin Range",7);
		//rangeEndText = new JTextField("End Range",7);
        
        //For layout purposes, put the buttons in a separate panel
        JPanel buttonPanel = new JPanel(); //use FlowLayout
			//buttonPanel.add(rangeBeginText);
			//buttonPanel.add(rangeEndText);
			buttonPanel.add(button_tostack);
			buttonPanel.add(button_all);
        	buttonPanel.add(button_green);
        	buttonPanel.add(button_red);
			buttonPanel.add(button_half);
			buttonPanel.add(button_undetermined);
			buttonPanel.add(button_save);
			buttonPanel.add(button_folderresults);
			

        //Add the buttons and the log to this panel.
        add(buttonPanel, BorderLayout.PAGE_START);
        add(logScrollPane, BorderLayout.CENTER);
    }

    public void actionPerformed(ActionEvent e) {

        //Handle clear button action.
        if (e.getSource() == button_tostack) {
			//IJ.log("stack");
			imp = WindowManager.getCurrentImage();
			imgName = imp.getShortTitle();
			origDir = imp.getOriginalFileInfo().directory;
			//make sure new directory exists
			newDir = origDir + "Processed\\";
			File makeDir = new File(newDir);
			makeDir.mkdirs();
			IJ.log(origDir+imgName);
			String str = "name="+imgName+" title=[] use";
			IJ.run("Images to Stack", str);
			IJ.run("ROI Manager...");
			roiMgr = RoiManager.getInstance();
			
		}else if (e.getSource() == button_all) {
			//IJ.log("all");
			roiMgr.addRoi(imp.getRoi());	//add current roi to roi manager
			int index = roiMgr.getCount()-1;	//get index of newly created roi
			roiMgr.select(index);				//select that index
			roiMgr.runCommand("Rename", "All");	//rename it
			roiMgr.runCommand("Show All");
			roiMgr.runCommand("Show None");
			IJ.run("Next Slice [>]");
			
        }else if (e.getSource() == button_green) {
			//IJ.log("green");
			roiMgr.addRoi(imp.getRoi());	//add current roi to roi manager
			int index = roiMgr.getCount()-1;	//get index of newly created roi
			roiMgr.select(index);				//select that index
			roiMgr.runCommand("Rename", "Green");	//rename it
			roiMgr.runCommand("Show All");
			roiMgr.runCommand("Show None");
			IJ.run("Next Slice [>]");
			
        }else if (e.getSource() == button_red) {
			//IJ.log("red");
			roiMgr.addRoi(imp.getRoi());	//add current roi to roi manager
			int index = roiMgr.getCount()-1;	//get index of newly created roi
			roiMgr.select(index);				//select that index
			roiMgr.runCommand("Rename", "Red");	//rename it
			roiMgr.runCommand("Show All");
			roiMgr.runCommand("Show None");
			IJ.run("Next Slice [>]");
			
		}else if (e.getSource() == button_half) {
			//IJ.log("half");
			roiMgr.addRoi(imp.getRoi());	//add current roi to roi manager
			int index = roiMgr.getCount()-1;	//get index of newly created roi
			roiMgr.select(index);				//select that index
			roiMgr.runCommand("Rename", "Half");	//rename it
			roiMgr.runCommand("Show All");
			roiMgr.runCommand("Show None");
			
		}else if (e.getSource() == button_undetermined) {
			//IJ.log("undetermined");
			roiMgr.addRoi(imp.getRoi());	//add current roi to roi manager
			int index = roiMgr.getCount()-1;	//get index of newly created roi
			roiMgr.select(index);				//select that index
			roiMgr.runCommand("Rename", "Undetermined");	//rename it
			roiMgr.runCommand("Show All");
			roiMgr.runCommand("Show None");
		}else if (e.getSource() == button_save) {
			//IJ.log("save");
			roiMgr.runCommand("Deselect");
			String roiSave = newDir+imgName+".zip";
			IJ.log(roiSave);
			roiMgr.runCommand("Save",roiSave);
			String imgSave = newDir+imgName+".tif";
			IJ.log(imgSave);
			IJ.save(imgSave);
			IJ.run("Close All");
			roiMgr.runCommand("Deselect");
			roiMgr.runCommand("Delete");
        }else if (e.getSource() == button_folderresults) {
			//IJ.log("results");
			
			getFolderResults();
        }
 
    }
	
	public void getFolderResults(){
		//only make a new results table if it's not already open
		if(!IJ.isResultsWindow()){
			resultTbl = new ResultsTable();
			resultTbl.show("Results");
		}
		
		File folder = new File(newDir);
		File[] files = folder.listFiles();
		for(File f : files){
			String fPath =  f.getPath();
			String fName = f.getName();
			if (!fPath.endsWith("/") & fPath.endsWith(".zip")){	//only open roi zip files
				if(roiMgr.getCount()>0){
					roiMgr.runCommand("Deselect");
					roiMgr.runCommand("Delete");
				}
				IJ.open(fPath);
				int count = roiMgr.getCount();
				Roi[] roi = roiMgr.getRoisAsArray();
				int rtIndex = resultTbl.getCounter(); //last row number = counter -1
				resultTbl.setValue("Folder",rtIndex, newDir);
				resultTbl.setValue("File",rtIndex, fName);
				for(int i=0; i<count; i++){
					String roiName = roiMgr.getName(i);
					String type = roi[i].getTypeAsString();
					PointRoi pRoi = (PointRoi)roi[i];
					double numPoints = (double)pRoi.getNCoordinates();
					//IJ.log(roiName +": " + numPoints);
					resultTbl.setValue(roiName,rtIndex, numPoints);
					//IJ.log("Counter: "+resultTbl.getCounter());
					//resultTbl.updateResults();
					
				}
				resultTbl.show("Results");
			}
		}
		if(roiMgr.getCount()>0){
			roiMgr.runCommand("Deselect");
			roiMgr.runCommand("Delete");
		}
		
		try{
			resultTbl.saveAs(newDir+"Results.csv");
		}catch(Exception e){
			IJ.log("problem saving results: " +e);
		}
		
		
	}



    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event dispatch thread.
     */
    private static void createAndShowGUI() {
        //Create and set up the window.
        JFrame frame = new JFrame("New Title");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        //Add content to the window.
        frame.add(new RLA_Wahid_Yeast_GUI());

        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }

    public static void mainrun() {
        //Schedule a job for the event dispatch thread:
        //creating and showing this application's GUI.
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                //Turn off metal's use of bold fonts
                UIManager.put("swing.boldMetal", Boolean.FALSE); 
                createAndShowGUI();
            }
        });
    }
    public void run(String arg) {
		//IJ.showMessage("My_Plugin","Hello world!");
		RLA_Wahid_Yeast_GUI.mainrun();
	}
}

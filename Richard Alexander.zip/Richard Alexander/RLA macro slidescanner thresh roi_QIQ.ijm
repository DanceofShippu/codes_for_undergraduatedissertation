//get thresh / min size / max size pix2

//get folder / file name

//ONLY open .tif files

Dialog.create("Enter Parameters");
Dialog.addMessage("This macro thresholds the image, \nruns Analyze Particles, and saves \nthe ROI set in the same folder.\n \n \nSelect the channel and pixel value\nto threshold, and set the min/max \nobject size for Analyze Particles. \n \n \n");
Dialog.addString("Only process",".tif");
Dialog.addNumber("Channel", 2);
Dialog.addNumber("Threshold", 1000);
Dialog.addNumber("Min Size (pixels^2)", 0);
Dialog.addNumber("Max Size (pixels^2)", 999999);

Dialog.show();

file_type = Dialog.getString();
channel = Dialog.getNumber();
thresh = Dialog.getNumber();
min_size = Dialog.getNumber();
max_size = Dialog.getNumber();

dir = getDirectory("Choose a Directory");
print(dir);
file_array = getFileList(dir);

for(i=0; i<file_array.length; i++){
	file_name = file_array[i];
	if(endsWith(file_name, file_type)){

		open(dir + file_name);
		run("Duplicate...", "duplicate channels=" + channel);
		//setAutoThreshold("Triangle dark");
		setThreshold(thresh, 999999);
		//run("Threshold...");
		setOption("BlackBackground", false);
		run("Convert to Mask");
		run("Erode");
		run("Erode");
		run("Dilate");
		run("Dilate");
		run("Analyze Particles...", "size="+min_size+"-"+max_size+" show=[Overlay Masks] clear add");
		kernel =  dir + file_name + ".zip";
		roiManager("Save", dir + file_name + ".zip");
		run("Close All");
		
	}
}


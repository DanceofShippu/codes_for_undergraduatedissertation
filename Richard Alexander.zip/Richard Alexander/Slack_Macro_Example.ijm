// RUN YOUR PLUGIN OR MACRO HERE
//run("My Plugin");

// Set Slack channel and message
message = "Test message sent from IJ to your channel";
channel = "notify-richard";

//--------------------------
// 	DON'T MODIFY
//--------------------------
passArgs = message + ";" + channel;
run("Slack Macro Send", passArgs);
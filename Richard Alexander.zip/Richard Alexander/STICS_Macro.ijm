setBatchMode(true);
origName = getTitle();
totSlices = nSlices;
substack = 8;
step = 4;
for(i=1; i<totSlices-substack; i++){
	selectWindow(origName);
	j = i+substack;
	kernel = " slices="+i+","+j;
	run("Make Substack...", kernel);
	rename("temp");
	kernel = " subregion=16 step=8 stics=1 x_offset=0.00000 y_offset=0.00000 velocity=8.00000 frame_time(min)=1.00000 pixel_size(um)=0.41513 normalize_vector_lengths? center_vectors? magnitude_threshhold?=0.00000";
	run("STICS map jru v2", kernel);
	kernel = "STICS Vectors - "+i;
	rename(kernel);
	selectWindow("temp");
	close();
}

run("Images to Stack", "name=STICS title=[] use");
setBatchMode(false);


//-----------------------------------original for loop
/*
for(i=1; i<=totSlices-step; i++){
	selectWindow(origName);
	j = i+step;
	kernel = " slices="+i+","+j;
	run("Make Substack...", kernel);
	rename("temp");
	run("STICS map jru v2", "subregion=32 step=16 stics=1 x_offset=0.00000 y_offset=0.00000 velocity=8.00000 frame_time(min)=1.00000 pixel_size(um)=0.41513 normalize_vector_lengths? center_vectors? magnitude_threshhold?=0.00000");
	kernel = "STICS Vectors - "+i;
	rename(kernel);
	selectWindow("temp");
	close();
}
*/

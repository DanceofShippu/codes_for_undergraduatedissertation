import ij.*;
import ij.process.*;
import ij.gui.*;
import java.awt.*;
import ij.plugin.*;
import ij.plugin.frame.*;

import java.io.*;
import java.lang.*;


public class Resume_Macro_Exceptions2 implements PlugIn {
	public static String pgLog = "RESUME_MACRO_EXCEPTIONS says: ";
	File dirWork;
	File dirResults;

	public void run(String arg) {
		
dirWork = new File(IJ.getDirectory("Choose the working directory"));
		dirResults = new File(IJ.getDirectory("Choose the results directory"));
		String args = dirWork+";"+dirResults;
		doMacro(1,args);
		//che
		doLog("Complete!! :)");
		
	}
	
	public void doMacro(int i, String args){
 //	public void doMacro(int i, File dirWork, File dirResults, String args){
		doLog("Starting run "+i);
		//run macro here
		IJ.runMacroFile("Batch_OpenMeasureSave_SLJCJS_v3.ijm",args);

		//check whether files still exist
		File[] fileList = dirWork.listFiles();
		for(File file : fileList){
			i=i+1;
			if(!file.isDirectory()){
				//files still exist, so restart and keep going!
				doLog("Error --------------------------------------------------------------------  resuming "+i);
				doMacro(i+1, args);
				break;
			}
		}
		
		
		//doMacro(i+1,args);


	}

	public void doLog(String text){
		IJ.log(pgLog+ text);
	}

}

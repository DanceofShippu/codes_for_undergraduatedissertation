//Created 2017-01-24 by Richard Alexander for the Stowers Institute for Medical Research

//print time
MonthNames = newArray("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
     DayNames = newArray("Sun", "Mon","Tue","Wed","Thu","Fri","Sat");
     getDateAndTime(year, month, dayOfWeek, dayOfMonth, hour, minute, second, msec);
     TimeString ="Date: "+DayNames[dayOfWeek]+" ";
     if (dayOfMonth<10) {TimeString = TimeString+"0";}
     TimeString = TimeString+dayOfMonth+"-"+MonthNames[month]+"-"+year+"\nTime: ";
     if (hour<10) {TimeString = TimeString+"0";}
     TimeString = TimeString+hour+":";
     if (minute<10) {TimeString = TimeString+"0";}
     TimeString = TimeString+minute+":";
     if (second<10) {TimeString = TimeString+"0";}
     TimeString = TimeString+second;
     print(TimeString);

//select folder, plot window, ch1-32
list = getList("image.titles");
  if (list.length==0)
     print("Plot window with spectra is not open");
  else {
     Dialog.create("Select plot window");
	 Dialog.addChoice("Plot Window:", list);
	 Dialog.addNumber("Start Channel:", 1);
	 Dialog.addNumber("End Channel:", 32);
	 Dialog.show();
	 plotName = Dialog.getChoice();
	 startC = Dialog.getNumber();
	 endC = Dialog.getNumber();
  }
  print(plotName);
  dir = getDirectory("Choose a Directory ");

//check if folder "unmix" exsists, and create if not TO DO <--------------------------
    	newFolder = dir+"unmix"+File.separator;
    	
		

  //setBatchMode(true);
  list = getFileList(dir);
  //Array.sort(list);
  
 for (i=0; i<list.length; i++) {
 	print(list[i]);
    if (endsWith(list[i], "/")){  // || File.isDirectory(list[i])
       print("skipped");
    }else{
    	if(!File.exists(newFolder)){
    			File.makeDirectory(newFolder);
    	}
    	//open(dir + list[i]);
    	run("Bio-Formats Importer", "open=["+dir + list[i]+"] color_mode=Default open_files rois_import=[ROI manager] view=Hyperstack stack_order=XYCZT x_coordinate_1=0 y_coordinate_1=0");
    	imageName = list[i];
    	print(imageName);
		run("linear unmixing jru v2", "spectral_image=["+imageName+"] spectra_plot=["+plotName+"] truncate_negative_values start_ch="+startC+" end_ch="+endC);
		selectWindow("Unmixed Stack");
		saveAs("tiff",newFolder+"unmix_"+list[i]);
		close(imageName);
		close("Unmix*");
	}
 }

	//print time
 	 MonthNames = newArray("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
     DayNames = newArray("Sun", "Mon","Tue","Wed","Thu","Fri","Sat");
     getDateAndTime(year, month, dayOfWeek, dayOfMonth, hour, minute, second, msec);
     TimeString ="Date: "+DayNames[dayOfWeek]+" ";
     if (dayOfMonth<10) {TimeString = TimeString+"0";}
     TimeString = TimeString+dayOfMonth+"-"+MonthNames[month]+"-"+year+"\nTime: ";
     if (hour<10) {TimeString = TimeString+"0";}
     TimeString = TimeString+hour+":";
     if (minute<10) {TimeString = TimeString+"0";}
     TimeString = TimeString+minute+":";
     if (second<10) {TimeString = TimeString+"0";}
     TimeString = TimeString+second;
     print(TimeString);

 print("----------DONE---------- ");

//translate the image based on first coord pair, then rotate based on second

getDimensions(width, height, channels, slices, frames)
Roi.getCoordinates(xpoints, ypoints)
IJ.log("("+xpoints[0]+","+ypoints[0]+") - ("+xpoints[1]+","+ypoints[1]+")")
xpoints=xpoints+100
IJ.log("("+xpoints[0]+","+ypoints[0]+") - ("+xpoints[1]+","+ypoints[1]+")")

//make canvas bigger before translation so that none is clipped
run("Canvas Size...", "width=286 height=326 position=Center zero");
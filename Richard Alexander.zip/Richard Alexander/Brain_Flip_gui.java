//To create a new GUI, Rename this file "new_filename", then find and replace all instences of
//"AndrewNPC_gui" with "new_filename".

import ij.*;
import ij.io.*;
import ij.process.*;
import ij.gui.*;
import java.awt.*;
import ij.plugin.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.*;
import java.util.ArrayList;

public class Brain_Flip_gui extends JPanel implements PlugIn , ActionListener{
    static private final String newline = "\n";
    JButton keepButton, flipButton, processButton, clearButton, showButton;
    //JTextField rangeBeginText, rangeEndText;
    JTextArea log;
    JFileChooser fc;
    String CellsFilePath, FidFilePath, Directory, SaveName, NameSub;
    Boolean clearTextFlag = true;
    int count = 0;
	ArrayList<Integer> flip_slices = new ArrayList<Integer>(1);
    String[] logListBegin = new String[100];
    String[] logListEnd = new String[100];
    File[] files;
	// CalcDistance CalcDist = new CalcDistance();
    
    public Brain_Flip_gui() {
        super(new BorderLayout());

        //Create the log first, because the action listeners
        //need to refer to it.
        log = new JTextArea(15,25);
        log.setMargin(new Insets(5,5,5,5));
        log.setEditable(false);
		log.setLineWrap(true);
		log.setWrapStyleWord(true);
		log.setText("Instructions:"+newline+
		"Image stack must have filename in slice label."+newline+newline+
		"-- File > Import > Image Sequence"+newline+
		"-- Image > Hyperstacks > Stack to Hyperstack"+newline+newline+
		"FLIP:    Flip image horizontally (advance slice)."+newline+
		"KEEP:  Keep image unchanged (advance slice)."+newline+newline+
		"CLEAR:  Start over from scratch."+newline+
		"SHOW:   List the slices to flip in the log window."+newline+newline+
		"PROCESS:  When done, flip and save all slices marked with the flip button.");
        JScrollPane logScrollPane = new JScrollPane(log);

        //Create a file chooser
        fc = new JFileChooser();
        fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

        //Uncomment one of the following lines to try a different
        //file selection mode.  The first allows just directories
        //to be selected (and, at least in the Java look and feel,
        //shown).  The second allows both files and directories
        //to be selected.  If you leave these lines commented out,
        //then the default mode (FILES_ONLY) will be used.
        //
        //fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        //fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);

        //Create the clear button.  
        keepButton = new JButton("Keep");
        keepButton.addActionListener(this);

        //Create the save range button.  
        flipButton = new JButton("Flip");
        flipButton.addActionListener(this);

		//Create the process button.  
        processButton = new JButton("Process");
        processButton.addActionListener(this);

		//Create Clear button
		clearButton = new JButton("Clear");
		clearButton.addActionListener(this);
		
        //Create Show button
		showButton = new JButton("Show");
		showButton.addActionListener(this);
		
        //For layout purposes, put the buttons in a separate panel
        JPanel buttonPanel = new JPanel(); //use FlowLayout
			buttonPanel.add(flipButton);
        	buttonPanel.add(keepButton);
        	
			
			
		JPanel bottomPanel = new JPanel();
			bottomPanel.add(clearButton);
			bottomPanel.add(showButton);
			bottomPanel.add(processButton);

        //Add the buttons and the log to this panel.
        add(buttonPanel, BorderLayout.PAGE_START);
        add(logScrollPane, BorderLayout.CENTER);
		add(bottomPanel, BorderLayout.PAGE_END);
    }

    public void actionPerformed(ActionEvent e) {

        //Handle keep button action.
        if (e.getSource() == keepButton) {
			ImagePlus imp = WindowManager.getCurrentImage();
			int c = imp.getC();
			int z = imp.getZ();
			int t = imp.getT();
			int slice = imp.getSlice();
			flip_slices.remove(new Integer(slice));
			//ImageStack stack = imp.getImageStack();
			imp.setPosition(c, z+1, t);

        //Handle flip button action.
        } else if (e.getSource() == flipButton) {
        	ImagePlus imp = WindowManager.getCurrentImage();
			int c = imp.getC();
			int z = imp.getZ();
			int t = imp.getT();
			int slice = imp.getSlice();
			flip_slices.add(slice);
			//ImageStack stack = imp.getImageStack();
			imp.setPosition(c,z+1, t);
			
		//Handle clear button action
        }else if (e.getSource() == clearButton) {
			flip_slices = new ArrayList<Integer>(1);
			IJ.log("Cleared memory. Starting over...");
			
		
		//Handle show button action
        }else if (e.getSource() == showButton) {
			IJ.log("Slices currently set to flip:");
			IJ.log(flip_slices.toString());
		
        //Handle process button action
        }else if (e.getSource() == processButton) {
			ImagePlus imp = WindowManager.getCurrentImage();
			ImageStack stack = imp.getImageStack();
			IJ.log("Flipping: " + flip_slices.toString());
			int tot = flip_slices.size();
			for(int i=0; i<tot; i++){
				int c = imp.getC();
				int z = flip_slices.get(i);
				int t = imp.getT();
				IJ.log("Flipping: "+z+"     ("+(i+1)+"/"+tot+")");
				imp.setPosition(c, z, t);
				
				int slice = imp.getCurrentSlice();
				IJ.log("Saving");
				String name = stack.getSliceLabel(slice).split(":")[0];
				IJ.log(name);
				String directory = imp.getOriginalFileInfo().directory.replace("\\","\\\\");
				String path = directory+name;
				IJ.log(path);
				
				IJ.run("Duplicate...", "duplicate slices="+z);
				IJ.run("Flip Horizontally", "stack");
				IJ.saveAs("Tiff", path);
				IJ.run("Close");
			}
        }
 
    }


//Function to delete slices
  public void deleteSlices(){
	for(File f : files){
		String current =  f.getPath();
		if (!f.getPath().endsWith("/") & f.getPath().endsWith(".tif")){
			ij.IJ.open(f.getPath());
			ImagePlus imp = WindowManager.getCurrentImage();
			ImageStack stack = imp.getImageStack();
			for(int j=0; j<count; j++){
				int first = Integer.parseInt(logListBegin[j]);
				int last = Integer.parseInt(logListEnd[j]);
				int count1 = 0;
				for (int i=first; i<=last; i++) {
					if ((i-count1)>stack.getSize())
						break;
					stack.deleteSlice(i-count1);
					count1++;
				}
			}
			String name = f.getName();
			String direct = f.getParent();
			log.append(direct + "\\ds_"+ name+ newline);
			IJ.save(direct + "\\ds_"+ name);
			imp.close();
		}
	}	
  }




    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event dispatch thread.
     */
    private static void createAndShowGUI() {
        //Create and set up the window.
        JFrame frame = new JFrame("Brain Flip");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        //Add content to the window.
        frame.add(new Brain_Flip_gui());

        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }

    public static void mainrun() {
        //Schedule a job for the event dispatch thread:
        //creating and showing this application's GUI.
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                //Turn off metal's use of bold fonts
                UIManager.put("swing.boldMetal", Boolean.FALSE); 
                createAndShowGUI();
                //IJ.log("\\Clear");
                //IJ.log("Count,Noise Tolerance (Find Maxima),ROI Type,ROI Bounds x,ROI Bounds y,ROI Bounds width,ROI Bounds height,Image Name,Full Path");
            }
        });
    }
    public void run(String arg) {
		//IJ.showMessage("My_Plugin","Hello world!");
		Brain_Flip_gui.mainrun();
	}
}

import ij.*;
import ij.process.*;
import ij.gui.*;
import ij.gui.GenericDialog;
import java.awt.*;
import ij.plugin.*;
import ij.plugin.frame.*;
import java.io.*;

public class rename_Files implements PlugIn {

	public void run(String arg) {

		GenericDialog gd = new GenericDialog("Find/Replace In File Name");
		gd.addStringField("   Search For:","");
		gd.addStringField("Replace With:","");
		gd.showDialog();
		String search_for = gd.getNextString();
		String replacement = gd.getNextString();
		
		File dir = new File(IJ.getDirectory("Choose a Directory "));
		File[] fileList = dir.listFiles();
		 
		for (int i = 0; i < fileList.length; i++) {
		 	IJ.log("orig:    " + dir.getAbsolutePath()
							+ "\\" + fileList[i]);
		 
			File oldFile = fileList[i];
			int index = oldFile.getName().indexOf(search_for);
			
			if(!oldFile.isDirectory() && index>=0){
				File newFile = new File(dir + "\\" +oldFile.getName().replace(search_for, replacement)); 	//must escape the "." character
			 	IJ.log("new:      " + newFile);
				
				boolean isFileRenamed = oldFile.renameTo(newFile);
			 
				if (isFileRenamed)
					IJ.log("......renamed");
				else
					IJ.log("......Error");
			}
			
		}
	}

}
